#!/bin/sh
java -cp ../lib/* MyFirstBot.java 
