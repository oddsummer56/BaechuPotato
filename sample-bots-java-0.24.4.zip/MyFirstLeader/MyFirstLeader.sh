#!/bin/sh
java -cp ../lib/* MyFirstLeader.java 
