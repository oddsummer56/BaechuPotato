#!/bin/sh
java -cp ../lib/* Walls.java 
